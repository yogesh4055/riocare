@extends('layouts.app')
@section("title","Dashboard")
@section('content')
<div class="row">
    <div class="col-md-12 grid-margin">
        <div class="row page-heading">
            <div class="col-12 col-xl-8 mb-xl-0 align-self-center align-items-center d-flex">
                <h4 class="font-weight-bold"><i class="menu-icon" data-feather="home"></i>Coming Soon</h4>
            </div>
        </div>
    </div>
</div>
<div class="row dashboard">
    <div class="col-12 col-lg-8">
        <h1>Coming Soon !!! </h1>
    </div>
</div>
@endsection



